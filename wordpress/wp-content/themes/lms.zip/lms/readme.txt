= LMS - Responsive Multi-Purpose Theme =

* by the DesignThemes team, http://themeforest.net/user/designthemes/