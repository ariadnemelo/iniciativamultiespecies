<?php
/** dttheme_option()
 * Objective:
 *		To get my theme options stored in database by the thme option page at back end.
 **/
if( !function_exists( 'dttheme_option' ) ){ 
	function dttheme_option($key1, $key2 = '') {
		$options = get_option ( IAMD_THEME_SETTINGS );
		$output = NULL;
	
		if (is_array ( $options )) {
	
			if (array_key_exists ( $key1, $options )) {
				$output = $options [$key1];
				if (is_array ( $output ) && ! empty ( $key2 )) {
					$output = (array_key_exists ( $key2, $output ) && (! empty ( $output [$key2] ))) ? $output [$key2] : NULL;
				}
			} else {
				$output = $output;
			}
		}
		return $output;
	}
}
// # --- **** dttheme_option() *** --- ###

/**
 * dttheme_default_option()
 * Objective:
 * To return my theme default options to store in database.
 */
if( !function_exists( 'dttheme_default_option' ) ){
	function dttheme_default_option() {
		
		$general = array(
					"logo" => "true",
					"enable-favicon" => "true",
					"disable-page-comment"	=>"true",
					"disable-portfolio-comment" => "true",
					"disable-teacher-comment" => "true",
					"disable-custom-scroll" =>"on",
					"enable-sticky-nav"	=>"true",
					"enable-landingpage-sticky-nav"	=>"true",
					"show-sociables" => "on",
					"global-page-layout" => "content-full-width",
					"show-footer" => "on",
					"footer-columns" => "4",
					"show-copyrighttext" => "on",
					'breadcrumb-delimiter' => 'default',
					"disable-picker"		=>"on",
					"show-footer-logo"		=>"on",
					"h4-phoneno" => "+ 123 456 7890",
					"h4-emailid" => get_option('admin_email'),
					"copyright-text" => 'Copyright &copy; 2014 LMS Theme All Rights Reserved | <a href="http://themeforest.net/user/designthemes"> Design Themes </a>');
					
		$appearance = array(
			"enable-header-cart" => "true",
			"disable-menu-settings" => "true",
			"skin" => "orange" , 
			"header_type" =>"header1",
			"body-font" => "Open Sans",
			'body-font-color' => '#808080',
			'body-font-size' => '14',
			'body-primary-color' => '#da853d',
			'body-secondary-color' => '#808080',
			'H1-font' => 'Raleway',
			'H1-font-color' => '#303030',
			'H1-size' => '36',
			'H2-font' => 'Raleway',
			'H2-font-color' => '#303030',
			'H2-size' => '30',
			'H3-font' => 'Raleway',
			'H3-font-color' => '#303030',
			'H3-size' => '24',
			'H4-font' => 'Raleway',
			'H4-font-color' => '#303030',
			'H4-size' => '20',
			'H5-font' => 'Raleway',
			'H5-font-color' => '#303030',
			'H5-size' => '18',
			'H6-font' => 'Raleway',
			'H6-font-color' => '#303030',
			'H6-size' => '16',
		);
	
		$integration = array(
				"post-googleplus-layout" => "small",
				"post-googleplus-lang" => "en_GB",
				"post-twitter-layout" => "vertical",
				"post-fb_like-layout" => "box_count",
				"post-fb_like-color-scheme" => "dark",
				"post-digg-layout" => "medium",
				"post-stumbleupon-layout" => "5",
				"post-linkedin-layout" => "2",
				"sb-post-googleplus" => "true",
				"sb-post-linkedin" => "true",
				"sb-post-stumbleupon" => "true",
				"sb-post-twitter" => "true",
				"sb-courses-googleplus" => "true",
				"sb-courses-linkedin" => "true",
				"sb-courses-fb_like" => "true",
				"sb-courses-twitter" => "true",
				"page-pintrest-layout" => "none",
				"page-googleplus-layout" => "small",
				"page-googleplus-lang" => "en_GB",
				"page-twitter-layout" => "blue",
				"page-fb_like-layout" => "box_count",
				"page-fb_like-color-scheme" => "light",
				"page-digg-layout" => "medium",
				"page-stumbleupon-layout" => "5",
				"page-linkedin-layout" => "2",
				"page-pintrest-layout" => "none");
	
		$mobile = array ("is-theme-responsive" => "true");
		
		$social = array ( 'social-1'=>array('icon'=>'fa-flickr','link'=>'#'), 'social-2'=>array('icon'=>'fa-google','link'=>'#'), 'social-3'=>array('icon'=>'fa-facebook','link'=>'#'));
	
		$seo = array ( "title-delimiter" => "|", 
				"post-title-format" => array ( "blog_title", "post_title" ),
				"page-title-format" => array ( "blog_title", "post_title" ),
				"archive-page-title-format" => array ( "blog_title", "date"	),
				"category-page-title-format" => array (	"blog_title", "category_title" ),
				"tag-page-title-format" => array ( "blog_title", "tag"),
				"search-page-title-format" => array ( "blog_title", "search" ),
				"404-page-title-format" => array ( "blog_title"));	
	
		$specialty = array (
				"archives-layout" => "with-right-sidebar",
				"archives-post-layout" => "one-column",
				"post-archives-layout" => "with-left-sidebar",
				"portfolio-archives-layout" => "with-right-sidebar",
				"teacher-archives-layout" => "both-sidebar",
				"search-layout" => "with-left-sidebar",
				"search-post-layout" => "one-column",
				"not-found-404-layout" => "content-full-width",
				"404-layout" => "content-full-width",
				"404-message" => "<h2> 404! </h2>
	<h3> The page you are looking for is Not Found! </h3>
	<p>Etiam sit amet orci eget eros faucibus tincidunt. Duis kalam <br> stefen kajas in the enter leo. Sed fringilla mauris sit amet nibh.  </p>");
	
		$woo = array(
			"shop-product-per-page" => "12",
			"shop-page-product-layout" => "one-third-column",
			"product-layout" => "with-right-sidebar",
			"product-category-layout" => "with-left-sidebar",
			"product-tag-layout" => "both-sidebar");
				
		$pagebuilder = array (
			'page' => 'page',
			'enable-pagebuilder' => false
		);
			
		$courses = array (
			'payment-method' => 's2member',
			'currency' => '$',
			'currency-s2member' => 'USD'
		);
				
		$data = array(
			"general" => $general,
			"appearance" => $appearance,
			"integration" => $integration,
			"mobile" => $mobile,
			"social" => $social,
			"seo" => $seo,
			"specialty" => $specialty,
			"dt_course" => $courses,
			"pagebuilder" => $pagebuilder,
			"woo" => $woo);		
						
		return $data;
	}
}
// # --- **** dttheme_default_option() *** --- ###

/** dttheme_adminpanel_tooltip()
 * Objective:
 *		To place tooltip content in thme option page at back end.
 * args:
 *		1. $tooltip = content which is shown as tooltip
 **/
if( !function_exists( 'dttheme_adminpanel_tooltip' ) ){
	function dttheme_adminpanel_tooltip($tooltip) {
		$output = "<div class='bpanel-option-help'>\n";
		$output .= "<a href='#'> <img src='" . IAMD_FW_URL . "theme_options/images/help.png' alt='' title='' /> </a>\n";
		$output .= "\r<div class='bpanel-option-help-tooltip'>\n";
		$output .= $tooltip;
		$output .= "\r</div>\n";
		$output .= "</div>\n";
		echo "{$output}";
	}
}
// # --- **** dttheme_adminpanel_tooltip() *** --- ###

/**
 * dttheme_adminpanel_image_preview()
 * Objective:
 * To place tooltip content in thme option page at back end.
 * args:
 * 1. $src = image source
 * 2. $backend = true - to get images placed in framework ? false - to get images stored in theme/images folder
 */
if( !function_exists( 'dttheme_adminpanel_image_preview' ) ){
	function dttheme_adminpanel_image_preview($src, $backend = true, $default = "no-image.jpg") {
		$default = ($backend) ? IAMD_FW_URL . "theme_options/images/" . $default : IAMD_BASE_URL . "images/" . $default;
		$src = !empty($src) ? $src : $default;
		
		$output = "<div class='bpanel-option-help'>\n";
		$output .= "<a href='#' class='a_image_preivew'> <img src='" . IAMD_FW_URL . "theme_options/images/image-preview.png' alt='' title='' /> </a>\n";
		$output .= "\r<div class='bpanel-option-help-tooltip imagepreview'>\n";
		$output .= "\r<img src='{$src}' data-default='{$default}' alt='' />";
		$output .= "\r</div>\n";
		$output .= "</div>\n";
		echo "{$output}";
	}
}
// # --- **** dttheme_adminpanel_image_preview() *** --- ###

/**
 * dttheme_pagelist()
 * Objective:
 * To create dropdown box with list of pages.
 * args:
 * 1. $id = page id
 * 2. $selected = ( true / false)
 */
if( !function_exists( 'dttheme_postlist' ) ){
	function dttheme_postlist($id, $selected, $class = "mytheme_select") {
		global $post;
		$args = array (
				'numberposts' => - 1 
		);
		
		$name = explode ( ",", $id );
		if (count ( $name ) > 1) {
			$name = "[{$name[0]}][{$name[1]}]";
		} else {
			$name = "[{$name[0]}]";
		}
		$name = ($class == "multidropdown") ? "mytheme{$name}[]" : "mytheme{$name}";
		$output = "<select name='{$name}' class='{$class}'>";
		$output .= "<option value=''>" . __ ( 'Select Post', 'lms' ) . "</option>";
		$posts = get_posts ( $args );
		foreach ( $posts as $post ) :
			$id = esc_attr ( $post->ID );
			$title = esc_html ( $post->post_title );
			$output .= "<option value='{$id}' " . selected ( $selected, $id, false ) . ">{$title}</option>";
		endforeach
		;
		$output .= "</select>\n";
		echo "{$output}";
	}
}
// # --- **** dttheme_postlist() *** --- ###

/**
 * dttheme_productlist()
 * Objective:
 * To create dropdown box with list of products.
 * args:
 * 1. $id = page id
 * 2. $selected = ( true / false)
 */
if( !function_exists( 'dttheme_productlist' ) ){
	function dttheme_productlist($id, $selected, $class = "mytheme_select") {
		global $post;
		$args = array (
				'numberposts' => - 1,
				'post_type' => 'product' 
		);
		
		$name = explode ( ",", $id );
		if (count ( $name ) > 1) {
			$name = "[{$name[0]}][{$name[1]}]";
		} else {
			$name = "[{$name[0]}]";
		}
		$name = ($class == "multidropdown") ? "mytheme{$name}[]" : "mytheme{$name}";
		$output = "<select name='{$name}' class='{$class}'>";
		$output .= "<option value=''>" . __ ( 'Select Product', 'lms' ) . "</option>";
		$posts = get_posts ( $args );
		foreach ( $posts as $post ) :
			$id = esc_attr ( $post->ID );
			$title = esc_html ( $post->post_title );
			$output .= "<option value='{$id}' " . selected ( $selected, $id, false ) . ">{$title}</option>";
		endforeach
		;
		$output .= "</select>\n";
		echo "{$output}";
	}
}
// # --- **** dttheme_productlist() *** --- ###

if( !function_exists( 'dttheme_product_taxonomy_list' ) ){
	function dttheme_product_taxonomy_list($id, $selected = '', $class = "mytheme_select", $taxonomy) {
		$name = explode ( ",", $id );
		if (count ( $name ) > 1) {
			$name = "[{$name[0]}][{$name[1]}]";
		} else {
			$name = "[{$name[0]}]";
		}
		$name = ($class == "multidropdown") ? "mytheme{$name}[]" : "mytheme{$name}";
		$output = "<select name='{$name}' class='{$class}'>";
		$output .= "<option value=''>" . __ ( 'Select', 'lms' ) . "</option>";
		$cats = get_categories ( "taxonomy={$taxonomy}&hide_empty=0" );
		
		foreach ( $cats as $cat ) :
			$id = esc_attr ( $cat->term_id );
			$title = esc_html ( $cat->name );
			$output .= "<option value='{$id}' " . selected ( $selected, $id, false ) . ">{$title}</option>";
		endforeach
		;
		$output .= "</select>\n";
		
		return $output;
	}
}

/**
 * dttheme_pagelist()
 * Objective:
 * To create dropdown box with list of pages.
 * args:
 * 1. $id = page id
 * 2. $selected = ( true / false)
 */
if( !function_exists( 'dttheme_pagelist' ) ){
	function dttheme_pagelist($id, $selected, $class = "mytheme_select") {
		$name = explode ( ",", $id );
		if (count ( $name ) > 1) {
			$name = "[{$name[0]}][{$name[1]}]";
		} else {
			$name = "[{$name[0]}]";
		}
		$name = ($class == "multidropdown") ? "mytheme{$name}[]" : "mytheme{$name}";
		$output = "<select name='{$name}' class='{$class}'>";
		$output .= "<option value=''>" . __ ( 'Select Page', 'lms' ) . "</option>";
		$pages = get_pages ( 'title_li=&orderby=name' );
		foreach ( $pages as $page ) :
			$id = esc_attr ( $page->ID );
			$title = esc_html ( $page->post_title );
			$output .= "<option value='{$id}' " . selected ( $selected, $id, false ) . ">{$title}</option>";
		endforeach
		;
		$output .= "</select>\n";
		echo "{$output}";
	}
}
// # --- **** dttheme_pagelist() *** --- ###

/**
 * dttheme_categorylist()
 * Objective:
 * To create dropdown box with list of categories.
 * args:
 * 1. $id = dropdown id
 * 2. $selected = ( true / false)
 * 3. $class = default class
 */
if( !function_exists( 'dttheme_categorylist' ) ){
	function dttheme_categorylist($id, $selected = '', $class = "mytheme_select") {
		$name = explode ( ",", $id );
		if (count ( $name ) > 1) {
			$name = "[{$name[0]}][{$name[1]}]";
		} else {
			$name = "[{$name[0]}]";
		}
		$name = ($class == "multidropdown") ? "mytheme{$name}[]" : "mytheme{$name}";
		$output = "<select name='{$name}' class='{$class}'>";
		$output .= "<option value=''>" . __ ( 'Select Category', 'lms' ) . "</option>";
		$cats = get_categories ( 'orderby=name&hide_empty=0' );
		foreach ( $cats as $cat ) :
			$id = esc_attr ( $cat->term_id );
			$title = esc_html ( $cat->name );
			$output .= "<option value='{$id}' " . selected ( $selected, $id, false ) . ">{$title}</option>";
		endforeach
		;
		$output .= "</select>\n";
		return $output;
	}
}
// # --- **** dttheme_categorylist() *** --- ###

if( !function_exists( 'dttheme_portfolio_categorylist' ) ){
	function dttheme_portfolio_categorylist($id, $selected = '', $class = "mytheme_select") {
		$name = explode ( ",", $id );
		if (count ( $name ) > 1) {
			$name = "[{$name[0]}][{$name[1]}]";
		} else {
			$name = "[{$name[0]}]";
		}
		$name = ($class == "multidropdown") ? "mytheme{$name}[]" : "mytheme{$name}";
		$cats = get_categories ( 'taxonomy=portfolio_entries&hide_empty=0' );
		if( is_array( $cats) ) {
			$output = "<select name='{$name}' class='{$class}'>";
			$output .= "<option value=''>" . __ ( 'Select Category', 'lms' ) . "</option>";
	
			foreach ( $cats as $cat ) :
				$id = esc_attr ( $cat->term_id );
				$title = esc_html ( $cat->name );
				$output .= "<option value='{$id}' " . selected ( $selected, $id, false ) . ">{$title}</option>";
			endforeach;
			$output .= "</select>\n";
		}
		return $output;
	}
}

/**
 * dttheme_listImage()
 * Args:
 * 1.
 * $dir = location of the folder from which you wnat to get images
 * Objective:
 * Returns an array that contains icon names located at $dir.
 */
if( !function_exists( 'dttheme_listImage' ) ){
	function dttheme_listImage($dir) {
		$sociables = array ();
		$icon_types = array (
				'jpg',
				'jpeg',
				'gif',
				'png' 
		);
		
		if (is_dir ( $dir )) {
			$handle = opendir ( $dir );
			while ( false !== ($dirname = readdir ( $handle )) ) {
				
				if ($dirname != "." && $dirname != "..") {
					$parts = explode ( '.', $dirname );
					$ext = strtolower ( $parts [count ( $parts ) - 1] );
					
					if (in_array ( $ext, $icon_types )) {
						$option = $parts [count ( $parts ) - 2];
						$sociables [$dirname] = str_replace ( ' ', '', $option );
					}
				}
			}
			closedir ( $handle );
		}
		
		return $sociables;
	}
}
// # --- **** dttheme_listImage() *** --- ###

/**
 * dttheme_sociables_selection()
 * Objective:
 * Returns selection box.
 */
if( !function_exists( 'dttheme_sociables_selection' ) ){
	function dttheme_sociables_selection($name = '', $selected = "") {
		
		$sociables =  array('fa-delicious' => 'Delicious', 'fa-dribbble' => 'Dribbble', 'fa-deviantart' => 'Deviantart', 'fa-digg' => 'Digg', 'fa-flickr' => 'Flickr', 'fa-twitter' => 'Twitter', 'fa-weibo' => 'Weibo', 'fa-youtube' => 'Youtube', 'fa-facebook' => 'Facebook', 'fa-google-plus' => 'Google Plus', 'fa-google' => 'Google', 'fa-pinterest' => 'Pinterest', 'fa-reddit' => 'Reddit', 'fa-yahoo' => 'Yahoo', 'fa-vimeo-square' => 'Vimeo', 'fa-stumbleupon' => 'Stumble Upon', 'fa-linkedin' => 'Linkedin', 'fa-skype' => 'Skype', 'fa-tumblr' => 'Tumblr', 'fa-instagram' => 'Instagram', 'fa-soundcloud' => 'SoundCloud', 'fa-vk' => 'VK');
		
		$name = ! empty ( $name ) ? "name='mytheme[social][{$name}][icon]'" : '';
		$out = "<select class='social-select' {$name}>"; // ame attribute will be added to this by jQuery menuAdd()
		foreach ( $sociables as $key => $value ) :
			$s = selected ( $key, $selected, false );
			$v = ucwords ( $value );
			$out .= "<option value='{$key}' {$s} >{$v}</option>";
		endforeach;
		$out .= "</select>";
		return $out;
		
	}
}
// # --- **** dttheme_sociables_selection() *** --- ###

/**
 * dttheme_admin_color_picker()
 * Objective:
 * Outputs the wordpress default color picker.
 * Args:
 * 1.Label
 * 2.Name
 * 3.Value - stored in db
 * 4.Tooltip
 */
if( !function_exists( 'dttheme_admin_color_picker' ) ){
	function dttheme_admin_color_picker($label, $name, $value, $tooltip = NULL) {
		global $wp_version;
		
		$output = "<div class='bpanel-option-set'>\n";
		if (! empty ( $label )) :
			$output .= "<label>{$label}</label>";
			$output .= "<div class='clear'></div>";
		
		
		endif;
		
		if (( float ) $wp_version >= 3.5) :
			$output .= "<input type='text' class='dt-color-field medium' name='{$name}' value='{$value}' />";
		 else :
			$output .= "<input type='text' class='medium color_picker_element' name='{$name}' value='{$value}' />";
			$output .= "<div class='color_picker'></div>";
		endif;
		echo "{$output}";
		if ($tooltip != NULL) :
			dttheme_adminpanel_tooltip ( $tooltip );
		
		
		endif;
		echo "</div>\n";
	}
}
// # --- **** dttheme_admin_color_picker() *** --- ###

/**
 * dttheme_admin_fonts()
 * Objective:
 * Outputs the fonts selection box.
 */
if( !function_exists( 'dttheme_admin_fonts' ) ){
	function dttheme_admin_fonts($label, $name, $selctedFont) {
		global $dt_google_fonts;
		$f = IAMD_SAMPLE_FONT;
		$css = (! empty ( $selctedFont )) ? 'style="font-family:' . $selctedFont . ';"' : '';
		$output = "<div class='mytheme-font-preview' {$css}>{$f}</div>";
		$output .= "<label>{$label}</label>";
		$output .= "<div class='clear'></div>";
		$output .= "<select class='mytheme-font-family-selector' name='{$name}'>";
		$output .= "<option value=''>" . __ ( "Select", 'lms' ) . "</option>";
		foreach ( $dt_google_fonts as $fonts ) :
			$rs = selected ( $fonts, $selctedFont, false );
			$output .= "<option value='{$fonts}' {$rs}>{$fonts}</option>";
		endforeach
		;
		$output .= "</select>";
		echo "{$output}";
	}
}
// # --- **** dttheme_admin_fonts() *** --- ###

/**
 * dttheme_admin_jqueryuislider()
 * Objective:
 * Outputs the jQurey UI Slider.
 */
if( !function_exists( 'dttheme_admin_jqueryuislider' ) ){
	function dttheme_admin_jqueryuislider($label, $id = '', $value = '', $px = "px") {
		$div_value = (! empty ( $value ) && ($px == "px")) ? $value . "px" : $value;
		$output = "<label>{$label}</label>";
		$output .= "<div class='clear'></div>";
		$output .= "<div id='{$id}' class='mytheme-slider' data-for='{$px}'></div>";
		$output .= "<input type='hidden' class='' name='{$id}' value='{$value}'/>";
		$output .= "<div class='mytheme-slider-txt'>{$div_value}</div>";
		echo "{$output}";
	}
}
// # --- **** dttheme_admin_jqueryuislider() *** --- ###

/**
 * getFolders()
 * Objective:
 */
if( !function_exists( 'getFolders' ) ){
	function getFolders($directory, $starting_with = "", $sorting_order = 0) {
		if (! is_dir ( $directory ))
			return false;
		$dirs = array ();
		$handle = opendir ( $directory );
		while ( false !== ($dirname = readdir ( $handle )) ) {
			if ($dirname != "." && $dirname != ".." && is_dir ( $directory . "/" . $dirname )) {
				if ($starting_with == "")
					$dirs [] = $dirname;
				else {
					$filter = strstr ( $dirname, $starting_with );
					if ($filter !== false)
						$dirs [] = $dirname;
				}
			}
		}
		
		closedir ( $handle );
		
		if ($sorting_order == 1) {
			rsort ( $dirs );
		} else {
			sort ( $dirs );
		}
		return $dirs;
	}
}
// # --- **** getFolders() *** --- ###

/**
 * dttheme_switch()
 * Objective:
 * Outputs the switch control at the backend.
 */
if( !function_exists( 'dttheme_switch' ) ){
	function dttheme_switch($label, $parent, $name) {
		$checked = ("true" == dttheme_option ( $parent, $name )) ? ' checked="checked"' : '';
		$switchclass = ("true" == dttheme_option ( $parent, $name )) ? 'checkbox-switch-on' : 'checkbox-switch-off';
		$out = "<div data-for='mytheme-{$parent}-{$name}' class='checkbox-switch {$switchclass}'></div>";
		$out .= "<input id='mytheme-{$parent}-{$name}' class='hidden' name='mytheme[{$parent}][{$name}]' type='checkbox' value='true' {$checked} />";
		echo "{$out}";
	}
}
// # --- **** dttheme_switch() *** --- ###

/**
 * dttheme_switch()
 * Objective:
 * Outputs the switch control at the backend.
 */
if( !function_exists( 'dttheme_switch_page' ) ){
	function dttheme_switch_page($label, $name, $value, $datafor = NULL) {
		$checked = ("true" == $value) ? ' checked="checked"' : '';
		$switchclass = ("true" == $value) ? 'checkbox-switch-on' : 'checkbox-switch-off';
		$datafor = ($datafor == NULL) ? $name : $datafor;
		$out = "<label>{$label}</label>";
		$out .= '<div class="clear"></div>';
		$out .= "<div data-for='{$datafor}' class='checkbox-switch {$switchclass}'></div>";
		$out .= "<input id='{$datafor}' class='hidden' name='{$name}' type='checkbox' value='true' {$checked} />";
		
		echo "{$out}";
	}
}
// # --- **** dttheme_switch() *** --- ###

/**
 * dttheme_bgtypes()
 * Objective:
 * Outputs the <select></select> control at the backend.
 */
if( !function_exists( 'dttheme_bgtypes' ) ){
	function dttheme_bgtypes($name, $parent, $child) {
		$args = array (
				"bg-patterns" => __ ( "Pattern", 'lms' ),
				"bg-custom" => __ ( "Custom Background", 'lms' ),
				"bg-none" => __ ( "None", 'lms' ) 
		);
		$out = '<div class="bpanel-option-set">';
		$out .= "<label>" . __ ( "Background Type", 'lms' ) . "</label>";
		$out .= "<div class='clear'></div>";
		$out .= "<select class='bg-type' name='{$name}'>";
		foreach ( $args as $k => $v ) :
			$rs = selected ( $k, dttheme_option ( $parent, $child ), false );
			$out .= "<option value='{$k}' {$rs}>{$v}</option>";
		endforeach
		;
		$out .= "</select>";
		$out .= '</div>';
		echo "{$out}";
	}
}
### --- ****  dttheme_bgtypes() *** --- ###

if( !function_exists( 'dttheme_standard_font' ) ){
	function dttheme_standard_font($label, $name, $selectedFont ){
		$fonts = array("Arial","Verdana, Geneva","Trebuchet","Georgia","Times New Roman","Tahoma, Geneva","Palatino","Helvetica");
		$output = "<label>{$label}</label>";
		$output .= "<div class='clear'></div>";
		$output .= "<select class='mytheme-select' name='{$name}'>";
		$output .= "<option value=''>" . __ ( "Select", 'lms' ) . "</option>";
		foreach ( $fonts as $font ) {
			$rs = selected ( $font, $selectedFont, false );
			$output .= "<option value='{$font}' {$rs}>{$font}</option>";
		}
		$output .= "</select>";
		echo "{$output}";
	}
}

if( !function_exists( 'dttheme_standard_font_style' ) ){
	function dttheme_standard_font_style($label, $name, $selectedFontStyle) {
		$styles = array("Normal","Italic","Bold","Bold Italic");
		$output = "<label>{$label}</label>";
		$output .= "<div class='clear'></div>";
		$output .= "<select class='mytheme-select' name='{$name}'>";
		$output .= "<option value=''>" . __ ( "Select", 'lms' ) . "</option>";
		foreach ( $styles as $style ) {
			$rs = selected ( $style, $selectedFontStyle, false );
			$output .= "<option value='{$style}' {$rs}>{$style}</option>";
		}
		$output .= "</select>";
		echo "{$output}";
	}
}

if( !function_exists( 'dttheme_custom_widgetarea_list' ) ){
	function dttheme_custom_widgetarea_list( $id, $selected = "", $class="mytheme_select", $sidebar) {
		$name = explode ( ",", $id );
		if (count ( $name ) > 1) {
			$name = "[{$name[0]}][{$name[1]}]";
		} else {
			$name = "[{$name[0]}]";
		}
	
		$name = ($class == "multidropdown") ? "mytheme{$name}[]" : "mytheme{$name}";
	
		$widgets = dttheme_option('widgetarea',$sidebar);
		$widgets = is_array($widgets) ? array_unique($widgets) : array();
		$widgets = array_filter($widgets);
	
		$output = "<select name='{$name}' class='{$class}'>";
		$output .= "<option value=''>" . __ ( 'Select Widget Area', 'lms' ) . "</option>";
		foreach( $widgets as $widget){
			$id = mb_convert_case($widget, MB_CASE_LOWER, "UTF-8");
			$id = str_replace(" ", "-", $widget);
			$output .= "<option value='{$id}' " . selected ( $selected, $id, false ) . ">{$widget}</option>";
		}
		$output .= "</select>\n";
		return $output;
		
	}
}