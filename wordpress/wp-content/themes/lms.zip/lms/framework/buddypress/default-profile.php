<?php
/**
 * Change teachers default landing tab.
 */
define('BP_DEFAULT_COMPONENT', 'profile' );
?>